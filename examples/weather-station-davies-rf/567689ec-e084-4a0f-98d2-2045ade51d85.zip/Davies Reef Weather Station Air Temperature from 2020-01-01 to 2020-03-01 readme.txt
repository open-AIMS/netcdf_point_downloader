Data Source: 
This data was sourced from the AIMS Time Series Explorer: https://apps.aims.gov.au/ts-explorer/?series_id=64&fromDate=2020-01-01T18:00:00&thruDate=2020-03-01T00:00:00

Metadata: 
Further information about this dataset can be found on the metadata record: https://apps.aims.gov.au/metadata/view/5fc91100-4ade-11dc-8f56-00008a07204e

Citation: 
This data is part of a larger time series, which should be cited using the following:
Australian Institute of Marine Science (AIMS). (2020). Northern Australia Automated Marine Weather and Oceanographic Stations, Site: Davies Reef, Parameter: Air Temperature, Time period: [2020-01-01 to 2020-03-01]. https://doi.org/10.25845/5c09bf93f315d, accessed 06 Apr 2024.

Licence: 
The data are available for use under the Creative Commons Attribution (CC-BY) licence: https://creativecommons.org/licenses/by/3.0/au/